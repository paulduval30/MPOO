package serie06;

import util.Contract;

import java.util.HashMap;

public class StdStock<E> implements Stock<E> {
    private HashMap<E, Integer> map;

    public StdStock() {
        this.map = new HashMap<E, Integer>();
    }

    @Override
    public int getNumber(E e) {
        Contract.checkCondition(e != null, "l'argument est null");

        return this.map.get(e);
        //return 0; //Lève une AssertionError via isInStock()
    }

    @Override
    public int getTotalNumber() {
        int total = 0;
        for (Integer n : map.values()) {
            total += n;
        }

        return total;
    }

    @Override
    public void addElement(E e) {
        Contract.checkCondition(e != null);
        Contract.checkCondition(this.map.containsKey(e));
        this.addElement(e, 1);
    }

    @Override
    public void addElement(E e, int qty) {
        Contract.checkCondition(e != null);
        Contract.checkCondition(this.map.containsKey(e));
        this.map.replace(e, map.get(e) + qty);
    }

    @Override
    public void removeElement(E e) {
        //On aurait pu appeler addElement(e, -1)
        Contract.checkCondition(e != null);
        Contract.checkCondition(this.map.containsKey(e));
        this.removeElement(e, 1);
    }

    @Override
    public void removeElement(E e, int qty) {
        Contract.checkCondition(e != null);
        Contract.checkCondition(this.map.containsKey(e));
        this.map.replace(e, map.get(e) - qty);
    }

    @Override
    public void reset() {
        for (E key : map.keySet()) {
            this.map.replace(key, 0);
        }
    }
}
