package serie06;

public enum CoinTypes {
    ONE(1),
    TWO(2),
    FIVE(5),
    TEN(10),
    TWENTY(20),
    FIFTY(50),
    ONE_HUNDRED(100),
    TWO_HUNDRED(200);

    private int faceValue;

    private CoinTypes(int faceValue) {
        this.faceValue = faceValue;
    }

    @Override
    public String toString() {
        String str = this.faceValue + " ct";
        if (this.faceValue != 1) {
            str += "s";
        }
        return str;
    }

    public int getFaceValue() {
        return faceValue;
    }

    public static CoinTypes getCoinType(int val) {
        for (CoinTypes coin : values()) {
            if (coin.faceValue == val)
                return coin;
        }
        return null;
    }
}
